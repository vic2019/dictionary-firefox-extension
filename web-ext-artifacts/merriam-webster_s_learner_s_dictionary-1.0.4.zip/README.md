# Merriam-Webster's Learner's Dictionary

A third-party browser add-on for the [Merriam-Webster's Learner's Dictionary with Audio](http://learnersdictionary.com/). 

Available for [Firefox](https://addons.mozilla.org/en-US/firefox/addon/learners-dictionary/?fbclid=IwAR0_iIPbCs3GpyKHD2zB_5i4SS2cy7Q1Vd3KRBCLNdTUEzhxT2svQaOhnO4) and [Chrome](https://chrome.google.com/webstore/detail/merriam-websters-learners/bibagmeonfmaeiicmgbngjdjahaaejll?fbclid=IwAR1Pm53_MniuTB6brD96absetkupDlHT_8CyZPsV0Qb3jR-yXR9mLUTy9A8) :)


